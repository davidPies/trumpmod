package turdcraft;

import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = turdcraft.modid, version = turdcraft.ver)
public class turdcraft{
	
    public static final String modid = "turdcraft";
    public static final String ver = "1.0";
    
    public static Item paper2;
    public static Item paper;
    
    @SidedProxy(clientSide="turdcraft.client", serverSide="turdcraft.server")
    public static sharedproxy proxy;
    
    @Instance
    public static turdcraft instance = new turdcraft();
    
    @EventHandler
    public void pre(FMLInitializationEvent e){
    	this.proxy.pre(e);
    	
    	paper = new paper(null);
    	paper2 = new paper2();
    }
    @EventHandler
    public void init(FMLInitializationEvent e){
    	this.proxy.init(e);
    }
}
