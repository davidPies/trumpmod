package turdcraft;

import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

public class server extends sharedproxy{

	@EventHandler
    public void pre(FMLInitializationEvent e){
		super.pre(e);
    }
	@EventHandler
    public void init(FMLInitializationEvent e){
		super.init(e);
    }
}