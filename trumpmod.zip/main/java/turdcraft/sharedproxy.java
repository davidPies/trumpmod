package turdcraft;

import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

public class sharedproxy {

	@EventHandler
    public void pre(FMLInitializationEvent e){
    }
	@EventHandler
    public void init(FMLInitializationEvent e){
    }
}