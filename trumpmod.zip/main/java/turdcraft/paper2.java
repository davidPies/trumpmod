package turdcraft;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class paper2 extends Item{
public paper2(){
	GameRegistry.registerItem(this, "paper2");
}
}
